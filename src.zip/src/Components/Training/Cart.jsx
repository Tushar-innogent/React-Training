import React from 'react'

const Cart = (...props) => {
  return (
    <>
        <h1>Cart</h1>
    </>
  )
}

export default Cart